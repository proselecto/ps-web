<?php return array('dependencies' => array(), 'version' => 'b4d297e7938fe5a0c932');
